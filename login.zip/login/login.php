<?php
$uname=$_GET['txtno'];
$hash=$_GET['txtpassword'];
$salt="";
if(isset($_GET['btnsubmit'])) {
$usrpw=sha1($salt.$hash);
$db=mysql_connect("localhost","root","");
mysql_select_db("bookshelf",$db);
$sql="select user_id,user_name,password from register where user_name='$uname' and password='$usrpw'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
if(trim($row['user_id'])!==""){
	echo "login successful!";
}
else
{
	echo "User-name and password do not match.";
}
}
?>