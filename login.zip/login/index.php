<?php
if(isset($_POST['btnsubmit'])) {
$uname=$_POST['txtno'];
$hash=$_POST['txtpassword'];
$salt="";
$usrpw=sha1($salt.$hash);
$db=mysql_connect("13.112.67.253","remoteuser","symhel123$");
mysql_select_db("asterisk",$db);
$sql="select extension_name,password from register where extension_name='$uname' and password='$usrpw'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
}
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Flat HTML5/CSS3 Login Form</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="login-page">
  <div class="form">
    <form class="login-form" method="POST" action="">
      <input type="text" name="txtno" placeholder="extension number"/>
      <input type="password" name="txtpassword" placeholder="password"/>
      <input type="submit" name="btnsubmit" value="LogIn" style="background-color:green;">
      <?php if(isset($_POST['btnsubmit'])) {
      if(trim($row['extension_name'])!==""){ ?>
  <p style="font-size: small;color: blue;"><?php echo "login successful!"; ?></p>
  <?php
}
else
{ ?>
  <p style="font-size: small;color: red;"><?php echo "User-name and password do not match."; ?></p>
<?php } }?>
    </form>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
