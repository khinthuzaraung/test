<?php
//echo password_hash("rasmuslerdorf", PASSWORD_DEFAULT);
$string="rasmuslerdorf";
$result = sha1($salt.$string);
echo $result;
/*echo password_hash("symhel123$", PASSWORD_DEFAULT);
$string="symhel123$";
$result = sha1($salt.$string);
echo $result;
$t=md5($string);
echo $t;*/
/*$password="symhel123$";
function generateHash($password) {
    if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) {
        $salt = '$2y$11$' . substr(md5(uniqid(rand(), true)), 0, 22);
        return crypt($password, $salt);
        $s=crypt($password,$salt);
        echo $s;
    }
}*/
/*$db = 'asterisk';
$dbuser = 'asteriskuser';
$dbpass = 'amp109';
$dbhost = '13.112.190.141';

$host=mysql_connect($dbhost,$dbuser,$dbpass);
mysql_select_db($db,$host); //or die("could not open database");*/
?>